n = int(input())
for row in range (n):
    # if row 
    print (' ' * 2 * (n - row) + '  * ' * (row + 1) + '' * 2 * (n - row))