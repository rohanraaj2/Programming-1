for term in range(9, -1, -1):
    print (term, end = '')
    if term > 0:
        print (', ', end = '')
    else:
        print()