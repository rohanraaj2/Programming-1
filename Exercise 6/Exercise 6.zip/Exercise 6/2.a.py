n = int(input())
for row in range (n):
    print ('* ' * (row + 1))